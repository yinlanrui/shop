<template>
    {{detail}}
</template>

<script>
    export default {
        name: "ShopDetail",
        props:['detail']
    }
</script>

<style scoped>

</style>